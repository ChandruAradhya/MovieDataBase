package com.project.moviedb.controller;

import java.util.Collections;

import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.project.moviedb.dto.MovieRequest;
import com.project.moviedb.dto.MovieResponse;
import com.project.moviedb.dto.ProgrammerRequest;
import com.project.moviedb.dto.ProgrammerResponse;
import com.project.moviedb.entity.Movie_Information;

import com.project.moviedb.service.MovieService;

@Controller
public class MovieController {

	@Autowired
	private MovieService service;

	private MovieRequest movieRequest;

	private MovieResponse movieResponse;

	private ProgrammerRequest pgRequest;

	private ProgrammerResponse pgResponse;




	@RequestMapping("/saveDetails")
	public ModelAndView saveMovieDetails(HttpServletRequest request,HttpServletResponse response) {
		movieRequest=new MovieRequest();

		String name=request.getParameter("name");
		movieRequest.setMovieName(name);

		String releaseDate=request.getParameter("releaseDate");
		movieRequest.setMovieReleaseDate(releaseDate);

		String budget=request.getParameter("budget");
		movieRequest.setMovieBudget(budget);

		String language=request.getParameter("language");
		movieRequest.setMovieLanguage(language);

		String collection=request.getParameter("collection");
		movieRequest.setBoxOfficeCollection(collection);

		String production=request.getParameter("production");
		movieRequest.setProductionHouse(production);

		String director=request.getParameter("director");
		movieRequest.setDirectorName(director);

		String hero=request.getParameter("hero");
		movieRequest.setHeroName(hero);

		String heroine=request.getParameter("heroine");
		movieRequest.setHeroineName(heroine);

		String producer=request.getParameter("producer");
		movieRequest.setProducerName(producer);

		String musicDirector=request.getParameter("musicDirector");
		movieRequest.setMusicDirectorName(musicDirector);

		String co_actor1=request.getParameter("co_actor1");
		movieRequest.setCo_actor1(co_actor1);

		String co_actor2=request.getParameter("co_actor2");
		movieRequest.setCo_actor2(co_actor2);

		String co_actor3=request.getParameter("co_actor3");
		movieRequest.setCo_actor3(co_actor3);

		String co_actor4=request.getParameter("co_actor4");
		movieRequest.setCo_actor4(co_actor4);

		String co_actor5=request.getParameter("co_actor5");
		movieRequest.setCo_actor5(co_actor5);



		movieResponse=new MovieResponse();

		String message=service.saveMovieDetails(movieRequest);

		movieResponse.setMessage(message);

		ModelAndView modview=new ModelAndView();
		modview.setViewName("response.jsp");
		modview.addObject("message", movieResponse.getMessage());

		return modview;

	}

	@RequestMapping("/login")
	public ModelAndView login(HttpServletRequest request,HttpServletResponse response) {

		pgRequest=new ProgrammerRequest();
		pgResponse=new ProgrammerResponse();

		String name=request.getParameter("name");
		String password=request.getParameter("password");

		pgRequest.setProgrammerName(name);
		pgRequest.setPassword(password);

		String result=service.login(pgRequest);

		pgResponse.setMessage(result);


		ModelAndView mav1=new ModelAndView();
		mav1.setViewName("loginsuccessful.jsp");
		mav1.addObject("loginsuccess", pgResponse.getMessage());

		return mav1;
	}



	@RequestMapping("/getMovie")
	public ModelAndView getMovie(HttpServletRequest request,HttpServletResponse response) {
		int c=0;
		movieResponse=new MovieResponse();
		String name=request.getParameter("name");
		Movie_Information info=service.getMovie(name);


		if(info.getMovieName().equalsIgnoreCase(name)) {
			movieResponse.setMovieName(info.getMovieName());
			movieResponse.setMovieBudget(info.getMovieBudget());
			movieResponse.setMovieLanguage(info.getMovieLanguage());
			movieResponse.setMovieReleaseDate(info.getMovieReleaseDate());
			movieResponse.setBoxOfficeCollection(info.getBoxOfficeCollection());
			movieResponse.setProductionHouse(info.getProductionHouse());
			movieResponse.setRatings(info.getReview().getRatings());
			c++;
		}




		String information="Movie Name:<h3>"+movieResponse.getMovieName()+"</h3> Movie Budget: <h3>"+movieResponse.getMovieBudget()+"</h3> Movie Language:<h3>"+movieResponse.getMovieLanguage()+"</h3> Movie Release Data:<h3>"+movieResponse.getMovieReleaseDate()+"</h3> Movie BoxOfficeCollection:<h3>"+movieResponse.getBoxOfficeCollection()+"</h3> Movie Production House:<h3>"+movieResponse.getProductionHouse()+"</h3> Movie Ratings:<h3>"+movieResponse.getRatings()+"</h3>";

		String notFound="Sorry,Movie not present in our Data Base...!!!!";

		if(c>0) {
			ModelAndView mav=new ModelAndView();
			mav.setViewName("details.jsp");
			mav.addObject("detail", information);
			return mav;
		}
		else {
			ModelAndView mav=new ModelAndView();
			mav.setViewName("notFound.jsp");
			mav.addObject("notFound", notFound);
			return mav;
		}

	}

	@RequestMapping("/getMoreMovie")
	public ModelAndView getMoreData(HttpServletRequest request,HttpServletResponse response) {
		int c=0;
		movieResponse=new MovieResponse();
		String name=request.getParameter("name");
		Movie_Information info=service.getMovie(name);

		if(name.equalsIgnoreCase(info.getMovieName())) {
			movieResponse.setMovieName(info.getMovieName());
			movieResponse.setMovieBudget(info.getMovieBudget());
			movieResponse.setMovieLanguage(info.getMovieLanguage());
			movieResponse.setMovieReleaseDate(info.getMovieReleaseDate());
			movieResponse.setBoxOfficeCollection(info.getBoxOfficeCollection());
			movieResponse.setProductionHouse(info.getProductionHouse());
			movieResponse.setDirectorName(info.getCac().getDirectorName());
			movieResponse.setHeroName(info.getCac().getHeroName());
			movieResponse.setHeroineName(info.getCac().getHeroineName());
			movieResponse.setProducerName(info.getCac().getProducerName());
			movieResponse.setMusicDirectorName(info.getCac().getMusicDirectorName());
			movieResponse.setCo_actor1(info.getCac().getCo_actor1());
			movieResponse.setCo_actor2(info.getCac().getCo_actor2());
			movieResponse.setCo_actor3(info.getCac().getCo_actor3());
			movieResponse.setCo_actor4(info.getCac().getCo_actor4());
			movieResponse.setCo_actor5(info.getCac().getCo_actor5());
			movieResponse.setRatings(info.getReview().getRatings());

			c++;
		}



		String inform="Movie Name:<h3>"+movieResponse.getMovieName()+"</h3>Movie Budget:<h3>"+movieResponse.getMovieBudget()+"</h3> Movie Language:<h3>"+movieResponse.getMovieLanguage()+"</h3> Movie Release Data:<h3>"+movieResponse.getMovieReleaseDate()+"</h3> Movie BoxOfficeCollection:<h3>"+movieResponse.getBoxOfficeCollection()+"</h3> Movie Production House:<h3>"+movieResponse.getProductionHouse()+"</h3> Movie Ratings:<h3>"+movieResponse.getRatings()+"</h3> Hero Name:<h3>"+movieResponse.getHeroName()+"</h3> Heroine Name:<h3>"+movieResponse.getHeroineName()+"</h3> Director Name:<h3>"+movieResponse.getDirectorName()+"</h3> Producer Name:<h3>"+movieResponse.getProducerName()+"</h3> MusicDirector Name:<h3>"+movieResponse.getMusicDirectorName()+"</h3> Co-Actors:<h3>"+movieResponse.getCo_actor1()+" , "+movieResponse.getCo_actor2()+" , "+movieResponse.getCo_actor3()+" , "+movieResponse.getCo_actor4()+" , "+movieResponse.getCo_actor5()+"</h3>";

		String message="Enterd wrong name.......";
		if(c>0) {
			ModelAndView mav=new ModelAndView();
			mav.setViewName("getMore.jsp");
			mav.addObject("moreData", inform);
			return mav;
		}

		else {
			ModelAndView mav=new ModelAndView();
			mav.setViewName("getMore.jsp");
			mav.addObject("moreData", message);
			return mav;
		}
	}

	@RequestMapping("/languageMovie")
	public ModelAndView langMovie(HttpServletRequest request,HttpServletResponse response) {



		ModelAndView mav=new ModelAndView();

		String language=request.getParameter("language");
		List<String> list=service.languageMovie(language);
		Collections.sort(list);


		mav.setViewName("movieList.jsp");
		mav.addObject("language", list);


		return mav;

	}

	@RequestMapping("/updateMovie")
	public ModelAndView updateMovie(HttpServletRequest request,HttpServletResponse response) {

		String name=request.getParameter("name");

		String value=request.getParameter("value");
		int choice=Integer.parseInt(request.getParameter("choice"));

		String message=service.updateMovieInfo(name, choice, value);

		ModelAndView mav=new ModelAndView();
		mav.setViewName("updateResult.jsp");
		mav.addObject("result", message);

		return mav;
	}


	@RequestMapping("/rating")
	public ModelAndView ratings(HttpServletRequest request,HttpServletResponse response) {

		movieRequest=new MovieRequest();

		String name=request.getParameter("name");
		int rating=Integer.parseInt(request.getParameter("ratings"));
		movieRequest.setRatings(rating);

		String message=service.ratings(name,movieRequest);
		ModelAndView mav=new ModelAndView();
		mav.setViewName("ratingView.jsp");
		mav.addObject("result", message);

		return mav;
	}

	@RequestMapping("/getReview")
	public ModelAndView getReview(HttpServletRequest request,HttpServletResponse response) {

		String name=request.getParameter("name");

		String result=service.getReview(name);

		ModelAndView mav=new ModelAndView();
		mav.setViewName("reviewView.jsp");
		mav.addObject("reviews", result);

		return mav;

	}

	@RequestMapping("/writeReview")
	public ModelAndView writeReview(HttpServletRequest request,HttpServletResponse response) {

		movieRequest=new MovieRequest();
		String name=request.getParameter("name");
		String review=request.getParameter("review");

		movieRequest.setReview(review);

		String result=service.writeReview(name,movieRequest);

		ModelAndView mav=new ModelAndView();
		mav.setViewName("reviewResult.jsp");
		mav.addObject("reviews", result);

		return mav;

	}
}
