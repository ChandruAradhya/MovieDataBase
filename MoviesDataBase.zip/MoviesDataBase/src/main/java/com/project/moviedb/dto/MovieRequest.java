package com.project.moviedb.dto;

public class MovieRequest {

	private String movieName;
	private String movieReleaseDate;
	private String movieBudget;
	private String movieLanguage;
	private String boxOfficeCollection;
	private String productionHouse;
	private String directorName;
	private String heroName;
	private String heroineName;
	private String producerName;
	private String musicDirectorName;
	private String co_actor1;
	private String co_actor2;
	private String co_actor3;
	private String co_actor4;
	private String co_actor5;
	private int ratings;
	private String review;
	private int raters;
	private int ratingCount;
	private int reviewers;
	

	public int getReviewers() {
		return reviewers;
	}
	public void setReviewers(int reviewers) {
		this.reviewers = reviewers;
	}
	public int getRatingCount() {
		return ratingCount;
	}
	public void setRatingCount(int ratingCount) {
		this.ratingCount = ratingCount;
	}
	public int getRaters() {
		return raters;
	}
	public void setRaters(int raters) {
		this.raters = raters;
	}
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieReleaseDate() {
		return movieReleaseDate;
	}
	public void setMovieReleaseDate(String movieReleaseDate) {
		this.movieReleaseDate = movieReleaseDate;
	}
	public String getMovieBudget() {
		return movieBudget;
	}
	public void setMovieBudget(String movieBudget) {
		this.movieBudget = movieBudget;
	}
	public String getMovieLanguage() {
		return movieLanguage;
	}
	public void setMovieLanguage(String movieLanguage) {
		this.movieLanguage = movieLanguage;
	}
	public String getBoxOfficeCollection() {
		return boxOfficeCollection;
	}
	public void setBoxOfficeCollection(String boxOfficeCollection) {
		this.boxOfficeCollection = boxOfficeCollection;
	}
	public String getProductionHouse() {
		return productionHouse;
	}
	public void setProductionHouse(String productionHouse) {
		this.productionHouse = productionHouse;
	}
	public String getDirectorName() {
		return directorName;
	}
	public void setDirectorName(String directorName) {
		this.directorName = directorName;
	}
	public String getHeroName() {
		return heroName;
	}
	public void setHeroName(String heroName) {
		this.heroName = heroName;
	}
	public String getHeroineName() {
		return heroineName;
	}
	public void setHeroineName(String heroineName) {
		this.heroineName = heroineName;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getMusicDirectorName() {
		return musicDirectorName;
	}
	public void setMusicDirectorName(String musicDirectorName) {
		this.musicDirectorName = musicDirectorName;
	}
	public String getCo_actor1() {
		return co_actor1;
	}
	public void setCo_actor1(String co_actor1) {
		this.co_actor1 = co_actor1;
	}
	public String getCo_actor2() {
		return co_actor2;
	}
	public void setCo_actor2(String co_actor2) {
		this.co_actor2 = co_actor2;
	}
	public String getCo_actor3() {
		return co_actor3;
	}
	public void setCo_actor3(String co_actor3) {
		this.co_actor3 = co_actor3;
	}
	public String getCo_actor4() {
		return co_actor4;
	}
	public void setCo_actor4(String co_actor4) {
		this.co_actor4 = co_actor4;
	}
	public String getCo_actor5() {
		return co_actor5;
	}
	public void setCo_actor5(String co_actor5) {
		this.co_actor5 = co_actor5;
	}
	public int getRatings() {
		return ratings;
	}
	public void setRatings(int ratings) {
		this.ratings = ratings;
	}
	public String getReview() {
		return review;
	}
	public void setReview(String review) {
		this.review = review;
	}

}
