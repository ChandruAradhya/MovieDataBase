package com.project.moviedb;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan(basePackages = {"com.project.moviedb","com.project.moviedb.controller","com.project.moviedb.repositoryimpl","com.project.moviedb.repository","com.project.moviedb.service","com.project.moviedb.entity","com.project.moviedb.dto"})
public class MovieConfig {

}
