package com.project.moviedb.repository;

import java.util.List;

import com.project.moviedb.dto.MovieRequest;
import com.project.moviedb.dto.ProgrammerRequest;
import com.project.moviedb.entity.Movie_Information;


public interface MovieRepository {

	public String saveMovieDetails(MovieRequest request);
	
	public Movie_Information getMovie(String name);
	
	public List<String> languageMovie(String language);
	
	public String updateMovieInfo(String name,int choice,String value);
	
	public String login(ProgrammerRequest request);
	
	public String rating(String name,MovieRequest movieRequest);
	
	public String getReview(String name);
	
	public String writeReview(String name,MovieRequest request);
}
