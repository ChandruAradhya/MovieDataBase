package com.project.moviedb.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class CastAndCrew {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int cacId;
	private String directorName;
	private String heroName;
	private String heroineName;
	private String producerName;
	private String musicDirectorName;
	private String co_actor1;
	private String co_actor2;
	private String co_actor3;
	private String co_actor4;
	private String co_actor5;
	
	
//	private Movie_Information moi;
//	
//	public Movie_Information getMoi() {
//		return moi;
//	}
//	public void setMoi(Movie_Information moi) {
//		this.moi = moi;
//	}
	public int getCacId() {
		return cacId;
	}
	public void setCacId(int cacId) {
		this.cacId = cacId;
	}
	public String getDirectorName() {
		return directorName;
	}
	public void setDirectorName(String directorName) {
		this.directorName = directorName;
	}
	public String getHeroName() {
		return heroName;
	}
	public void setHeroName(String heroName) {
		this.heroName = heroName;
	}
	public String getHeroineName() {
		return heroineName;
	}
	public void setHeroineName(String heroineName) {
		this.heroineName = heroineName;
	}
	public String getProducerName() {
		return producerName;
	}
	public void setProducerName(String producerName) {
		this.producerName = producerName;
	}
	public String getMusicDirectorName() {
		return musicDirectorName;
	}
	public void setMusicDirectorName(String musicDirectorName) {
		this.musicDirectorName = musicDirectorName;
	}
	public String getCo_actor1() {
		return co_actor1;
	}
	public void setCo_actor1(String co_actor1) {
		this.co_actor1 = co_actor1;
	}
	public String getCo_actor2() {
		return co_actor2;
	}
	public void setCo_actor2(String co_actor2) {
		this.co_actor2 = co_actor2;
	}
	public String getCo_actor3() {
		return co_actor3;
	}
	public void setCo_actor3(String co_actor3) {
		this.co_actor3 = co_actor3;
	}
	public String getCo_actor4() {
		return co_actor4;
	}
	public void setCo_actor4(String co_actor4) {
		this.co_actor4 = co_actor4;
	}
	public String getCo_actor5() {
		return co_actor5;
	}
	public void setCo_actor5(String co_actor5) {
		this.co_actor5 = co_actor5;
	}
	
	
}
