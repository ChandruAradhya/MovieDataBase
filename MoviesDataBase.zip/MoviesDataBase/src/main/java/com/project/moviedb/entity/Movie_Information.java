package com.project.moviedb.entity;

import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Movie_Information {

	@Id
	private String movieName;
	private String movieReleaseDate;
	private String movieBudget;
	private String movieLanguage;
	private String boxOfficeCollection;
	private String productionHouse;
	public String getMovieName() {
		return movieName;
	}
	public void setMovieName(String movieName) {
		this.movieName = movieName;
	}
	public String getMovieReleaseDate() {
		return movieReleaseDate;
	}
	public void setMovieReleaseDate(String movieReleaseDate) {
		this.movieReleaseDate = movieReleaseDate;
	}
	public String getMovieBudget() {
		return movieBudget;
	}
	public void setMovieBudget(String movieBudget) {
		this.movieBudget = movieBudget;
	}
	public String getMovieLanguage() {
		return movieLanguage;
	}
	public void setMovieLanguage(String movieLanguage) {
		this.movieLanguage = movieLanguage;
	}
	public String getBoxOfficeCollection() {
		return boxOfficeCollection;
	}
	public void setBoxOfficeCollection(String boxOfficeCollection) {
		this.boxOfficeCollection = boxOfficeCollection;
	}
	public String getProductionHouse() {
		return productionHouse;
	}
	public void setProductionHouse(String productionHouse) {
		this.productionHouse = productionHouse;
	}

	@OneToOne(fetch = FetchType.EAGER)
	private CastAndCrew cac;

	@OneToOne(fetch = FetchType.EAGER)
	private Reviews review;
	
	public CastAndCrew getCac() {
		
		return cac;
	}
	public void setCac(CastAndCrew cac) {
		this.cac = cac;
	}
	public Reviews getReview() {
		
		return review;
	}
	public void setReview(Reviews review) {
		this.review = review;
	}

}
