package com.project.moviedb.repositoryimpl;

import java.util.List;


import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;
import org.springframework.stereotype.Repository;

import com.project.moviedb.dto.MovieRequest;
import com.project.moviedb.dto.ProgrammerRequest;
import com.project.moviedb.entity.CastAndCrew;
import com.project.moviedb.entity.Movie_Information;
import com.project.moviedb.entity.ProgrammerData;
import com.project.moviedb.entity.Reviews;
import com.project.moviedb.repository.MovieRepository;

@Repository
public class MovieRepositoryImpl implements MovieRepository {

	private Movie_Information movie;
	private CastAndCrew cac;
	private Reviews review;
	private ProgrammerData pgData;

	public String saveMovieDetails(MovieRequest request) {

		movie=new Movie_Information();
		cac=new CastAndCrew();
		review=new Reviews();

		movie.setMovieName(request.getMovieName());
		movie.setMovieReleaseDate(request.getMovieReleaseDate());
		movie.setMovieBudget(request.getMovieBudget());
		movie.setMovieLanguage(request.getMovieLanguage());
		movie.setBoxOfficeCollection(request.getBoxOfficeCollection());
		movie.setProductionHouse(request.getProductionHouse());
		cac.setHeroName(request.getHeroName());
		cac.setHeroineName(request.getHeroineName());
		cac.setDirectorName(request.getDirectorName());
		cac.setProducerName(request.getProducerName());
		cac.setMusicDirectorName(request.getMusicDirectorName());
		cac.setCo_actor1(request.getCo_actor1());
		cac.setCo_actor2(request.getCo_actor2());
		cac.setCo_actor3(request.getCo_actor3());
		cac.setCo_actor4(request.getCo_actor4());
		cac.setCo_actor5(request.getCo_actor5());
		review.setRatings(request.getRatings());
		review.setReview(request.getReview());
		movie.setCac(cac);
		movie.setReview(review);


		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();
		sess.save(movie);
		sess.save(cac);
		sess.save(review);
		tran.commit();
		sess.close();
		sf.close();



		String message="Movie Information Saved Successfully";
		return message;
	}


	public Movie_Information getMovie(String name) {

		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();



		Query<Movie_Information> query = sess.createQuery("from Movie_Information where movieName=?1 ", Movie_Information.class);
		query.setParameter(1, name);
		List<Movie_Information> list= query.getResultList();
		for(int i=0;i<list.size();i++) {
			movie=list.get(i);
		}

		sess.close();
		sf.close();
		return movie;
	}


	public List<String> languageMovie(String language) {

		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();


		Query<String> query = sess.createQuery("select movieName from Movie_Information where movieLanguage=?1 ");
		query.setParameter(1, language);
		List<String> list=query.list();

		sess.close();
		sf.close();
		return list;
	}


	public String updateMovieInfo(String name,int choice,String value) {

		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();


		Query<Movie_Information> query = sess.createQuery("from Movie_Information where movieName=?1 ", Movie_Information.class);
		query.setParameter(1, name);
		List<Movie_Information> list= query.getResultList();
		for(int i=0;i<list.size();i++) {
			movie=list.get(i);
		}

		String message=null;

		if(movie.getMovieName().equalsIgnoreCase(name)) {
			switch(choice) {
			case 1:movie.setMovieName(value);
			break;
			case 2:movie.setMovieLanguage(value);
			break;
			case 3:movie.setMovieBudget(value);
			break;
			case 4:movie.setBoxOfficeCollection(value);
			break;
			case 5:movie.setMovieReleaseDate(value);
			break;
			case 6:movie.setProductionHouse(value);
			break;
			case 7:movie.getCac().setHeroName(value);
			break;
			case 8:movie.getCac().setHeroineName(value);
			break;
			case 9:movie.getCac().setDirectorName(value);
			break;
			case 10:movie.getCac().setProducerName(value);
			break;
			case 11:movie.getCac().setMusicDirectorName(value);
			break;
			default:;
			}
			sess.save(movie);
			tran.commit();
			sess.close();
			sf.close();
			message="Movie Detail Updated Successfully......";
		}
		else {
			message="Entered Wrong Name or Movie Not Present in the DataBase.........";
		}

		return message;

	}


	public String login(ProgrammerRequest request) {

		pgData=new ProgrammerData();
		pgData.setProgrammerName("Chandru");
		pgData.setPassword("Appu@8055");
		String message=null;
		if(request.getProgrammerName().equals(pgData.getProgrammerName()) && request.getPassword().equals(pgData.getPassword())) {

			message="Login Successful.........!";
		}
		else {
			message="Login Failed.........<br>Enter Correct User Name/Password......";
		}

		return message;
	}


	public String rating(String name,MovieRequest movieRequest) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();

		int ratings=0;


		Query<Movie_Information> query = sess.createQuery("from Movie_Information where movieName=?1 ", Movie_Information.class);
		query.setParameter(1, name);
		List<Movie_Information> list= query.getResultList();
		for(int i=0;i<list.size();i++) {
			movie=list.get(i);
		}
		if(movie.getMovieName().equalsIgnoreCase(name)) {
			int c=movie.getReview().getRaters();
			int rateSum=movieRequest.getRatings()+movie.getReview().getRatingCount();
			c++;
			ratings=rateSum/c;
			movie.getReview().setRaters(c);
			movie.getReview().setRatingCount(rateSum);
			movie.getReview().setRatings(ratings);
			sess.save(movie);
			tran.commit();
			sess.close();
			sf.close();
			return "Movie Rating= "+movie.getReview().getRatings();
		}
		else {
			return "Entered Wrong Name or Movie Not Present in the DataBase........."; 
		}
	}


	public String getReview(String name) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();



		Query<Movie_Information> query = sess.createQuery("from Movie_Information where movieName=?1 ", Movie_Information.class);
		query.setParameter(1, name);
		List<Movie_Information> list= query.getResultList();
		for(int i=0;i<list.size();i++) {
			movie=list.get(i);
		}
		if(movie.getMovieName().equalsIgnoreCase(name)) {
			return movie.getReview().getReview();
		}
		else {
			return "Entered Wrong Name or Movie Not Present in the DataBase.........";
		}
	}

	public String writeReview(String name,MovieRequest request) {
		Configuration config=new Configuration().configure().addAnnotatedClass(Movie_Information.class).addAnnotatedClass(CastAndCrew.class).addAnnotatedClass(Reviews.class);
		SessionFactory sf=config.buildSessionFactory();
		Session sess=sf.openSession();
		Transaction tran=sess.beginTransaction();


		Query<Movie_Information> query = sess.createQuery("from Movie_Information where movieName=?1 ", Movie_Information.class);
		query.setParameter(1, name);
		List<Movie_Information> list= query.getResultList();
		for(int i=0;i<list.size();i++) {
			movie=list.get(i);
		}
		if(movie.getMovieName().equalsIgnoreCase(name)) {
			int c=movie.getReview().getReviewers();
			c++;
			String reviewAdd=movie.getReview().getReview()+"<br>Review-"+c+":<br>"+request.getReview()+"<br><br>";
			movie.getReview().setReviewers(c);
			movie.getReview().setReview(reviewAdd);
			sess.save(movie);
			tran.commit();
			sess.close();
			sf.close();
			return "Your Review Saved Successfully,Thank You.......!!!";
		}
		else {
			return "Entered Wrong Name or Movie Not Present in the DataBase.........";
		}
	}

}
