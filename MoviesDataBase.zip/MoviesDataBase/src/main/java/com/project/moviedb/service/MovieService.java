package com.project.moviedb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.moviedb.dto.MovieRequest;
import com.project.moviedb.dto.ProgrammerRequest;
import com.project.moviedb.entity.Movie_Information;
import com.project.moviedb.repository.MovieRepository;
import com.project.moviedb.repositoryimpl.MovieRepositoryImpl;

@Service
public class MovieService {

	@Autowired
	private MovieRepositoryImpl repositoryImpl;

	private MovieRepository repository;

	public String saveMovieDetails(MovieRequest request) {
		repository=new MovieRepositoryImpl();

		String message=repository.saveMovieDetails(request);
		return message;
	}

	public Movie_Information getMovie(String name) {
		repository=new MovieRepositoryImpl();

		Movie_Information info=repository.getMovie(name);
		return info;
	}

	public List<String> languageMovie(String language){
		repository=new MovieRepositoryImpl();

		List<String> lang=repository.languageMovie(language);
		return lang;

	}

	public String updateMovieInfo(String name,int choice,String value) {
		repository=new MovieRepositoryImpl();

		String info=repository.updateMovieInfo(name, choice, value);
		return info;

	}

	public String login(ProgrammerRequest request) {
		repository=new MovieRepositoryImpl();

		String response=repository.login(request);
		return response;

	}

	public String ratings(String name,MovieRequest movieRequest) {

		repository=new MovieRepositoryImpl();

		String response=repository.rating(name,movieRequest);
		return response;
	}

	public String getReview(String name) {

		repository=new MovieRepositoryImpl();

		String response=repository.getReview(name);
		return response;
	}

	public String writeReview(String name,MovieRequest request) {

		repository=new MovieRepositoryImpl();

		String response=repository.writeReview(name,request);
		return response;
	}
}
