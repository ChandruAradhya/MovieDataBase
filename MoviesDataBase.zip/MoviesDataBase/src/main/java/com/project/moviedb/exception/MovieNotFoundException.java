package com.project.moviedb.exception;

public class MovieNotFoundException extends RuntimeException {

	private String message;

	public MovieNotFoundException(String message) {
		
		this.message = message;
	}
	
	public String getMessage() {
		return message;
	}
}
