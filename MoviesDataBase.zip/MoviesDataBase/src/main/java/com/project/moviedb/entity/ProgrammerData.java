package com.project.moviedb.entity;


public class ProgrammerData {

	
	private String programmerName;
	private String password;
	
	
	public String getProgrammerName() {
		return programmerName;
	}

	public void setProgrammerName(String programmerName) {
		this.programmerName = programmerName;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
	
}
